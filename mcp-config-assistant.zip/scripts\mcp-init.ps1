#!/usr/bin/env pwsh
<#
.SYNOPSIS
    MCP配置初始化脚本 - 生成标准MCP配置文件
.DESCRIPTION
    交互式生成MCP配置文件，支持多种模板
.PARAMETER Template
    指定模板名称
.PARAMETER Install
    生成后自动安装配置
.PARAMETER Output
    输出文件路径
.EXAMPLE
    ./mcp-init.ps1
    ./mcp-init.ps1 -Template python-server
    ./mcp-init.ps1 -Template python-server -Install
#>

param(
    [string]$Template = "",
    [switch]$Install,
    [string]$Output = "./mcp-config.yaml"
)

$Colors = @{
    Success = "Green"
    Info = "Cyan"
    Warning = "Yellow"
}

# 内置模板
$Templates = @{
    "python-server" = @{
        Name = "Python MCP服务器"
        Description = "适用于Python开发的MCP服务器配置"
        Content = @"
mcpServers:
  my-python-server:
    command: python
    args:
      - "-m"
      - "mcp.server"
      - "--transport"
      - "stdio"
    env:
      PYTHONPATH: "./src"
      MCP_LOG_LEVEL: "INFO"
    disabled: false
    autoApprove: []
"@
    }
    "node-server" = @{
        Name = "Node.js MCP服务器"
        Description = "适用于Node.js开发的MCP服务器配置"
        Content = @"
mcpServers:
  my-node-server:
    command: node
    args:
      - "./dist/server.js"
      - "--transport"
      - "stdio"
    env:
      NODE_ENV: "production"
      MCP_LOG_LEVEL: "INFO"
    disabled: false
    autoApprove: []
"@
    }
    "stdio-bridge" = @{
        Name = "STDIO桥接配置"
        Description = "用于命令行工具集成的桥接配置"
        Content = @"
mcpServers:
  stdio-bridge:
    command: npx
    args:
      - "-y"
      - "@modelcontextprotocol/server-stdio-bridge"
    env: {}
    disabled: false
    autoApprove: []
"@
    }
    "multi-server" = @{
        Name = "多服务器配置"
        Description = "包含多个MCP服务器的复杂配置"
        Content = @"
mcpServers:
  python-server:
    command: python
    args:
      - "-m"
      - "mcp.server"
    env:
      PYTHONPATH: "./src"
    disabled: false
    autoApprove: []
  
  node-server:
    command: node
    args:
      - "./dist/server.js"
    env:
      NODE_ENV: "production"
    disabled: false
    autoApprove: []
  
  filesystem:
    command: npx
    args:
      - "-y"
      - "@modelcontextprotocol/server-filesystem"
      - "./workspace"
    env: {}
    disabled: false
    autoApprove: []
"@
    }
}

function Show-TemplateMenu {
    Write-Host "`n📋 可用模板:" -ForegroundColor $Colors.Info
    Write-Host "================================" -ForegroundColor $Colors.Info
    
    $index = 1
    foreach ($key in $Templates.Keys) {
        $t = $Templates[$key]
        Write-Host "$index. $($t.Name)" -ForegroundColor White -NoNewline
        Write-Host " ($key)" -ForegroundColor Gray
        Write-Host "   $($t.Description)" -ForegroundColor DarkGray
        $index++
    }
    Write-Host ""
}

function Select-Template {
    Show-TemplateMenu
    
    $choices = @($Templates.Keys)
    $selection = Read-Host "请选择模板 (1-$($choices.Count))"
    
    try {
        $index = [int]$selection - 1
        if ($index -ge 0 -and $index -lt $choices.Count) {
            return $choices[$index]
        }
    } catch {
        # 尝试直接匹配模板名称
        if ($Templates.ContainsKey($selection)) {
            return $selection
        }
    }
    
    Write-Host "❌ 无效选择，使用默认模板" -ForegroundColor Red
    return "python-server"
}

function Get-ConfigContent {
    param([string]$TemplateKey)
    
    if ($Templates.ContainsKey($TemplateKey)) {
        return $Templates[$TemplateKey].Content
    }
    
    # 尝试从文件加载
    $templatePath = "$PSScriptRoot/../assets/templates/$TemplateKey.yaml"
    if (Test-Path $templatePath) {
        return Get-Content $templatePath -Raw
    }
    
    Write-Host "⚠️ 模板 '$TemplateKey' 未找到，使用默认模板" -ForegroundColor $Colors.Warning
    return $Templates["python-server"].Content
}

function New-MCPConfig {
    param(
        [string]$TemplateKey,
        [string]$OutputPath
    )
    
    Write-Host "`n🚀 初始化MCP配置" -ForegroundColor $Colors.Info
    Write-Host "================================" -ForegroundColor $Colors.Info
    
    # 获取配置内容
    $configContent = Get-ConfigContent -TemplateKey $TemplateKey
    
    # 交互式定制
    Write-Host "`n📝 配置定制 (直接回车使用默认值):" -ForegroundColor $Colors.Info
    
    $serverName = Read-Host "服务器名称 (默认: my-mcp-server)"
    if (-not $serverName) { $serverName = "my-mcp-server" }
    
    $configContent = $configContent -replace "my-python-server|my-node-server", $serverName
    
    # 检查输出目录
    $outputDir = Split-Path $OutputPath -Parent
    if ($outputDir -and -not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
        Write-Host "📁 创建目录: $outputDir" -ForegroundColor $Colors.Info
    }
    
    # 检查文件是否已存在
    if (Test-Path $OutputPath) {
        $overwrite = Read-Host "⚠️  文件已存在，是否覆盖? (y/N)"
        if ($overwrite -ne "y" -and $overwrite -ne "Y") {
            Write-Host "❌ 操作已取消" -ForegroundColor Red
            return $false
        }
    }
    
    # 写入文件
    $configContent | Out-File -FilePath $OutputPath -Encoding UTF8
    Write-Host "✅ 配置文件已生成: $OutputPath" -ForegroundColor $Colors.Success
    
    return $true
}

function Install-Config {
    param([string]$ConfigPath)
    
    Write-Host "`n📦 安装配置..." -ForegroundColor $Colors.Info
    
    # 复制到用户配置目录
    $userConfigDir = "$env:USERPROFILE/.mcp"
    if (-not (Test-Path $userConfigDir)) {
        New-Item -ItemType Directory -Path $userConfigDir -Force | Out-Null
    }
    
    $userConfigPath = "$userConfigDir/config.yaml"
    Copy-Item $ConfigPath $userConfigPath -Force
    Write-Host "✅ 配置已安装到: $userConfigPath" -ForegroundColor $Colors.Success
    
    # 设置环境变量提示
    Write-Host "`n💡 下一步:" -ForegroundColor $Colors.Warning
    Write-Host "   1. 编辑配置文件，添加你的服务器路径和API密钥" -ForegroundColor Gray
    Write-Host "   2. 运行 'mcp-assistant check' 验证配置" -ForegroundColor Gray
    Write-Host "   3. 启动你的MCP服务器" -ForegroundColor Gray
}

# 主流程
Write-Host "`n🛠️  MCP配置初始化工具 v1.0.0" -ForegroundColor $Colors.Info

# 选择模板
if (-not $Template) {
    $Template = Select-Template
}

# 生成配置
$success = New-MCPConfig -TemplateKey $Template -OutputPath $Output

if ($success -and $Install) {
    Install-Config -ConfigPath $Output
}

Write-Host "`n✨ 完成!" -ForegroundColor $Colors.Success
