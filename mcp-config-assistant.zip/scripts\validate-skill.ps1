#!/usr/bin/env pwsh
<#
.SYNOPSIS
    MCP Config Assistant Skill Validation Script
.DESCRIPTION
    Validates the skill package integrity and functionality
#>

param(
    [string]$SkillPath = "."
)

$Colors = @{
    Success = "Green"
    Error = "Red"
    Warning = "Yellow"
    Info = "Cyan"
}

$Tests = @{
    Passed = 0
    Failed = 0
    Warnings = 0
}

function Test-Result {
    param(
        [string]$Name,
        [bool]$Passed,
        [string]$Message = ""
    )
    
    if ($Passed) {
        Write-Host "[PASS] $Name" -ForegroundColor $Colors.Success
        $Tests.Passed++
    } else {
        Write-Host "[FAIL] $Name" -ForegroundColor $Colors.Error
        if ($Message) {
            Write-Host "       $Message" -ForegroundColor Gray
        }
        $Tests.Failed++
    }
}

Write-Host "`n========================================" -ForegroundColor $Colors.Info
Write-Host "   MCP Config Assistant Skill Validation" -ForegroundColor $Colors.Info
Write-Host "========================================" -ForegroundColor $Colors.Info
Write-Host "Skill Path: $SkillPath`n" -ForegroundColor Gray

# Test 1: SKILL.md exists
Write-Host "[1] Checking core files..." -ForegroundColor $Colors.Info
$skillMdPath = "$SkillPath/SKILL.md"
Test-Result -Name "SKILL.md exists" -Passed (Test-Path $skillMdPath)

# Test 2: SKILL.md format
if (Test-Path $skillMdPath) {
    $content = Get-Content $skillMdPath -Raw
    Test-Result -Name "SKILL.md has YAML Frontmatter" -Passed ($content -match "^---")
    Test-Result -Name "SKILL.md has name field" -Passed ($content -match "(?m)^name:\s*\S+")
    Test-Result -Name "SKILL.md has description field" -Passed ($content -match "(?m)^description:")
    Test-Result -Name "SKILL.md has version field" -Passed ($content -match "(?m)^version:")
    Test-Result -Name "SKILL.md has price field" -Passed ($content -match "(?m)^price:")
    Test-Result -Name "SKILL.md has license field" -Passed ($content -match "(?m)^license:")
}

# Test 3: Scripts
Write-Host "`n[2] Checking scripts..." -ForegroundColor $Colors.Info
$scriptsPath = "$SkillPath/scripts"
Test-Result -Name "scripts directory exists" -Passed (Test-Path $scriptsPath)

if (Test-Path $scriptsPath) {
    Test-Result -Name "mcp-check.ps1 exists" -Passed (Test-Path "$scriptsPath/mcp-check.ps1")
    Test-Result -Name "mcp-init.ps1 exists" -Passed (Test-Path "$scriptsPath/mcp-init.ps1")
    Test-Result -Name "mcp-fix.ps1 exists" -Passed (Test-Path "$scriptsPath/mcp-fix.ps1")
    Test-Result -Name "validate-skill.ps1 exists" -Passed (Test-Path "$scriptsPath/validate-skill.ps1")
}

# Test 4: Templates
Write-Host "`n[3] Checking templates..." -ForegroundColor $Colors.Info
$templatesPath = "$SkillPath/assets/templates"
Test-Result -Name "templates directory exists" -Passed (Test-Path $templatesPath)

if (Test-Path $templatesPath) {
    Test-Result -Name "python-server.yaml exists" -Passed (Test-Path "$templatesPath/python-server.yaml")
    Test-Result -Name "node-server.yaml exists" -Passed (Test-Path "$templatesPath/node-server.yaml")
    Test-Result -Name "multi-server.yaml exists" -Passed (Test-Path "$templatesPath/multi-server.yaml")
}

# Test 5: References
Write-Host "`n[4] Checking references..." -ForegroundColor $Colors.Info
$referencesPath = "$SkillPath/references"
Test-Result -Name "references directory exists" -Passed (Test-Path $referencesPath)

if (Test-Path $referencesPath) {
    Test-Result -Name "troubleshooting-guide.md exists" -Passed (Test-Path "$referencesPath/troubleshooting-guide.md")
}

# Test 6: Pricing check
Write-Host "`n[5] Checking pricing..." -ForegroundColor $Colors.Info
if (Test-Path $skillMdPath) {
    $content = Get-Content $skillMdPath -Raw
    
    $hasPrice = $content -match "(?m)^price:\s*[0-9]+(\.[0-9]+)?"
    Test-Result -Name "price field is set" -Passed $hasPrice
    
    $hasLicense = $content -match "(?m)^license:\s*\S+"
    Test-Result -Name "license field is set" -Passed $hasLicense
    
    if ($hasPrice) {
        $priceMatch = [regex]::Match($content, "(?m)^price:\s*([0-9]+(\.[0-9]+)?)")
        if ($priceMatch.Success) {
            $price = $priceMatch.Groups[1].Value
            Write-Host "       Price: `$$price" -ForegroundColor $Colors.Info
        }
    }
}

# Summary
Write-Host "`n========================================" -ForegroundColor $Colors.Info
Write-Host "   Validation Summary" -ForegroundColor $Colors.Info
Write-Host "========================================" -ForegroundColor $Colors.Info
Write-Host "Passed:  $($Tests.Passed)" -ForegroundColor $Colors.Success
Write-Host "Failed:  $($Tests.Failed)" -ForegroundColor $Colors.Error
Write-Host "Warnings: $($Tests.Warnings)" -ForegroundColor $Colors.Warning

if ($Tests.Failed -eq 0) {
    Write-Host "`n[SUCCESS] All validation passed!" -ForegroundColor $Colors.Success
    exit 0
} else {
    Write-Host "`n[FAILED] Please fix the issues above." -ForegroundColor $Colors.Error
    exit 1
}
