---
name: mcp-config-assistant
description: 'MCP (Model Context Protocol) 配置助手 - 一键检测、诊断和修复MCP配置问题，支持自动配置生成和可视化配置管理'
version: 1.0.0
type: skill
tags: ['mcp', 'config', 'diagnostic', 'automation', 'troubleshooting']
price: 9.99
license: commercial
---

# MCP 配置助手

## 概述

MCP配置助手是一个专门解决MCP (Model Context Protocol) 配置复杂度高问题的智能工具。它能够自动检测配置问题、生成正确的配置文件、提供可视化配置界面，并支持一键修复常见错误。

**核心能力：**
- 🔍 自动检测MCP配置问题
- 🛠️ 一键生成标准配置
- 📊 可视化配置管理
- 🔧 智能错误诊断与修复
- 📚 内置配置模板库

## 适用场景

1. **初次配置MCP服务器** - 不知道从何开始，需要引导式配置
2. **配置问题排查** - MCP工具无法正常工作，需要诊断原因
3. **多环境配置管理** - 开发/测试/生产环境配置切换
4. **团队协作配置同步** - 统一团队MCP配置标准
5. **配置文件版本管理** - 追踪配置变更历史

## 使用方法

### 基本用法

#### 1. 检测当前MCP配置状态

```bash
# 检测全局配置
mcp-assistant check

# 检测指定项目配置
mcp-assistant check --project ./my-project

# 详细诊断模式
mcp-assistant check --verbose
```

#### 2. 生成标准配置文件

```bash
# 交互式生成配置
mcp-assistant init

# 基于模板快速生成
mcp-assistant init --template python-server

# 生成并自动安装
mcp-assistant init --install
```

#### 3. 修复配置问题

```bash
# 自动修复检测到的问题
mcp-assistant fix

# 修复指定问题类型
mcp-assistant fix --issue env-vars

# 预览修复内容（不实际执行）
mcp-assistant fix --dry-run
```

### 高级用法

#### 配置模板管理

```bash
# 列出可用模板
mcp-assistant templates list

# 添加自定义模板
mcp-assistant templates add ./my-template.yaml --name my-template

# 导出当前配置为模板
mcp-assistant templates export --output ./backup-template.yaml
```

#### 环境变量管理

```bash
# 检查环境变量配置
mcp-assistant env check

# 生成环境变量模板
mcp-assistant env generate --format bash

# 自动加载环境变量
mcp-assistant env load --file .env.mcp
```

#### 配置验证与测试

```bash
# 验证配置文件语法
mcp-assistant validate ./mcp-config.yaml

# 测试MCP服务器连接
mcp-assistant test --server my-server

# 性能测试
mcp-assistant benchmark --duration 30s
```

## 资源文件

### 脚本 (scripts/)

| 脚本 | 功能 | 用法 |
|------|------|------|
| `mcp-check.ps1` / `mcp-check.sh` | 配置检测 | `./mcp-check.ps1 [--verbose]` |
| `mcp-init.ps1` / `mcp-init.sh` | 初始化配置 | `./mcp-init.ps1 [--template <name>]` |
| `mcp-fix.ps1` / `mcp-fix.sh` | 修复配置 | `./mcp-fix.ps1 [--dry-run]` |
| `mcp-env.ps1` / `mcp-env.sh` | 环境变量管理 | `./mcp-env.ps1 [check|generate|load]` |
| `mcp-validate.ps1` / `mcp-validate.sh` | 配置验证 | `./mcp-validate.ps1 <config-file>` |

### 配置文件模板 (assets/templates/)

| 模板 | 描述 | 适用场景 |
|------|------|----------|
| `python-server.yaml` | Python MCP服务器模板 | 开发Python MCP服务器 |
| `node-server.yaml` | Node.js MCP服务器模板 | 开发Node.js MCP服务器 |
| `stdio-bridge.yaml` | STDIO桥接配置 | 命令行工具集成 |
| `sse-server.yaml` | SSE服务器配置 | 实时通信场景 |
| `multi-server.yaml` | 多服务器配置 | 复杂项目配置 |

### 参考资料 (references/)

- `mcp-spec.md` - MCP协议规范摘要
- `troubleshooting-guide.md` - 常见问题排查指南
- `best-practices.md` - 配置最佳实践
- `env-vars-reference.md` - 环境变量参考手册

## 最佳实践

### 1. 项目初始化流程

```bash
# 1. 进入项目目录
cd my-project

# 2. 检测现有配置
mcp-assistant check

# 3. 基于检测结果初始化
mcp-assistant init --template python-server

# 4. 验证配置
mcp-assistant validate ./mcp-config.yaml

# 5. 测试连接
mcp-assistant test --server my-server
```

### 2. 团队协作配置

```bash
# 导出团队标准配置
mcp-assistant templates export --output .mcp/team-standard.yaml

# 新成员快速配置
mcp-assistant init --template ./.mcp/team-standard.yaml
```

### 3. CI/CD集成

```yaml
# .github/workflows/mcp-check.yml
name: MCP Config Check
on: [push, pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Check MCP Config
        run: |
          mcp-assistant check --verbose
          mcp-assistant validate ./mcp-config.yaml
```

### 4. 安全注意事项

- 永远不要将敏感信息（API密钥、密码）直接写入配置文件
- 使用环境变量或密钥管理服务
- 定期轮换API密钥
- 配置文件应加入.gitignore

## 故障排查

### 常见问题

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| MCP服务器无法启动 | 环境变量缺失 | 运行 `mcp-assistant env check` |
| 配置格式错误 | YAML语法错误 | 运行 `mcp-assistant validate` |
| 权限不足 | 文件权限问题 | 运行 `mcp-assistant fix --issue permissions` |
| 连接超时 | 网络或防火墙 | 检查网络配置和防火墙规则 |
| 工具发现失败 | 服务器未注册 | 运行 `mcp-assistant test --server <name>` |

### 诊断命令

```bash
# 完整系统诊断
mcp-assistant diagnose --full

# 查看详细日志
mcp-assistant logs --follow

# 导出诊断报告
mcp-assistant diagnose --export ./diagnostic-report.json
```

## 定价与许可

- **个人版**: $9.99 (一次性购买)
- **团队版**: $49.99 (最多10人)
- **企业版**: 联系销售

许可类型: 商业许可
包含: 终身更新、邮件支持

## 更新日志

### v1.0.0 (2026-03-26)
- 初始版本发布
- 支持配置检测、初始化、修复核心功能
- 包含5个配置模板
- 支持Windows/macOS/Linux

---

**需要帮助？** 联系支持: support@openclaw.dev
