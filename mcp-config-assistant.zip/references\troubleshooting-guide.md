# MCP配置故障排查指南

## 常见问题速查

### 1. MCP服务器无法启动

**症状**: 运行配置检测时显示"未检测到运行的MCP服务器"

**排查步骤**:
1. 检查配置文件路径是否正确
2. 验证服务器启动命令是否可执行
3. 检查环境变量是否设置
4. 查看服务器日志输出

**解决方案**:
```bash
# 手动测试服务器启动
python -m mcp.server --transport stdio

# 检查端口占用
lsof -i :3000  # macOS/Linux
netstat -ano | findstr :3000  # Windows
```

### 2. 配置文件格式错误

**症状**: YAML解析错误，或配置项无法识别

**常见错误**:
- 使用制表符而非空格缩进
- 缺少必需的根节点 `mcpServers:`
- 环境变量语法错误

**解决方案**:
```bash
# 使用修复工具
mcp-assistant fix --issue format

# 手动验证YAML
python -c "import yaml; yaml.safe_load(open('mcp-config.yaml'))"
```

### 3. 环境变量未生效

**症状**: 服务器启动但缺少必要的环境变量

**排查步骤**:
1. 检查 `.env.mcp` 文件是否存在
2. 验证环境变量名称是否正确
3. 确认环境变量已加载

**解决方案**:
```bash
# 生成环境变量模板
mcp-assistant env generate

# 手动加载环境变量
source .env.mcp  # macOS/Linux
# 或
. .\.env.mcp  # PowerShell
```

### 4. 权限不足

**症状**: 无法读取或写入配置文件

**解决方案**:
```bash
# 修复文件权限
mcp-assistant fix --issue permissions

# 手动修改权限 (macOS/Linux)
chmod 644 mcp-config.yaml

# 手动修改权限 (Windows)
icacls mcp-config.yaml /grant %username%:RW
```

### 5. 连接超时

**症状**: MCP客户端无法连接到服务器

**排查步骤**:
1. 检查服务器是否正在运行
2. 验证端口配置是否正确
3. 检查防火墙设置

**解决方案**:
```bash
# 测试连接
mcp-assistant test --server my-server

# 检查服务器状态
ps aux | grep mcp  # macOS/Linux
Get-Process | Where-Object {$_.ProcessName -like "*mcp*"}  # Windows
```

## 错误代码参考

| 错误代码 | 描述 | 解决方案 |
|---------|------|----------|
| E001 | 配置文件不存在 | 运行 `mcp-assistant init` |
| E002 | YAML解析错误 | 运行 `mcp-assistant fix --issue format` |
| E003 | 环境变量缺失 | 运行 `mcp-assistant env generate` |
| E004 | 服务器启动失败 | 检查服务器路径和依赖 |
| E005 | 连接超时 | 检查网络和防火墙设置 |
| E006 | 权限不足 | 运行 `mcp-assistant fix --issue permissions` |

## 调试模式

启用详细日志输出:

```bash
# 设置日志级别
export MCP_LOG_LEVEL=DEBUG  # macOS/Linux
$env:MCP_LOG_LEVEL = "DEBUG"  # Windows PowerShell

# 运行检测
mcp-assistant check --verbose
```

## 获取帮助

如果以上方法无法解决问题:

1. 导出诊断报告:
   ```bash
   mcp-assistant diagnose --export ./diagnostic-report.json
   ```

2. 查看详细日志:
   ```bash
   mcp-assistant logs --follow
   ```

3. 联系支持: support@openclaw.dev
