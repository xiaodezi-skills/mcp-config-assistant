#!/usr/bin/env pwsh
<#
.SYNOPSIS
    MCP配置检测脚本 - 自动检测MCP配置问题
.DESCRIPTION
    检测MCP配置文件的完整性、环境变量设置、服务器连接状态等
.PARAMETER Verbose
    显示详细检测信息
.PARAMETER Project
    指定项目路径
.EXAMPLE
    ./mcp-check.ps1
    ./mcp-check.ps1 -Verbose
    ./mcp-check.ps1 -Project ./my-project
#>

param(
    [switch]$Verbose,
    [string]$Project = "."
)

# 颜色定义
$Colors = @{
    Success = "Green"
    Warning = "Yellow"
    Error = "Red"
    Info = "Cyan"
}

# 检测结果
$Results = @{
    Passed = 0
    Warnings = 0
    Errors = 0
    Checks = @()
}

function Write-CheckResult {
    param(
        [string]$Name,
        [string]$Status,
        [string]$Message,
        [string]$Suggestion = ""
    )
    
    $icon = switch ($Status) {
        "PASS" { "✓"; $Colors.Success }
        "WARN" { "⚠"; $Colors.Warning }
        "FAIL" { "✗"; $Colors.Error }
        default { "ℹ"; $Colors.Info }
    }
    
    Write-Host "[$($icon[0])] $Name" -ForegroundColor $icon[1]
    if ($Verbose -or $Status -ne "PASS") {
        Write-Host "    $Message" -ForegroundColor Gray
        if ($Suggestion) {
            Write-Host "    💡 建议: $Suggestion" -ForegroundColor $Colors.Warning
        }
    }
    
    $Results.Checks += @{
        Name = $Name
        Status = $Status
        Message = $Message
        Suggestion = $Suggestion
    }
    
    switch ($Status) {
        "PASS" { $Results.Passed++ }
        "WARN" { $Results.Warnings++ }
        "FAIL" { $Results.Errors++ }
    }
}

function Test-MCPConfigFile {
    $configPaths = @(
        "$Project/mcp-config.yaml",
        "$Project/mcp-config.yml",
        "$Project/.mcp/config.yaml",
        "$env:USERPROFILE/.mcp/config.yaml"
    )
    
    $foundConfig = $null
    foreach ($path in $configPaths) {
        if (Test-Path $path) {
            $foundConfig = $path
            break
        }
    }
    
    if ($foundConfig) {
        try {
            $content = Get-Content $foundConfig -Raw
            # 简单YAML验证
            if ($content -match "mcpServers|servers") {
                Write-CheckResult -Name "配置文件存在" -Status "PASS" -Message "找到配置文件: $foundConfig"
                return $true
            } else {
                Write-CheckResult -Name "配置文件格式" -Status "WARN" -Message "配置文件可能缺少必要的mcpServers配置" -Suggestion "检查配置文件内容或重新生成"
                return $false
            }
        } catch {
            Write-CheckResult -Name "配置文件读取" -Status "FAIL" -Message "无法读取配置文件: $_" -Suggestion "检查文件权限"
            return $false
        }
    } else {
        Write-CheckResult -Name "配置文件存在" -Status "FAIL" -Message "未找到MCP配置文件" -Suggestion "运行 'mcp-assistant init' 生成配置"
        return $false
    }
}

function Test-EnvironmentVariables {
    $requiredVars = @(
        "MCP_SERVER_PATH",
        "MCP_API_KEY"
    )
    
    $missingVars = @()
    foreach ($var in $requiredVars) {
        if (-not [Environment]::GetEnvironmentVariable($var)) {
            $missingVars += $var
        }
    }
    
    if ($missingVars.Count -eq 0) {
        Write-CheckResult -Name "环境变量" -Status "PASS" -Message "所有必需的环境变量已设置"
    } else {
        Write-CheckResult -Name "环境变量" -Status "WARN" -Message "缺少环境变量: $($missingVars -join ', ')" -Suggestion "运行 'mcp-assistant env generate' 生成环境变量模板"
    }
}

function Test-MCPServerConnection {
    # 检查常见的MCP服务器端口
    $commonPorts = @(3000, 8080, 8000, 5000)
    $listeningPorts = @()
    
    foreach ($port in $commonPorts) {
        try {
            $connection = Test-NetConnection -ComputerName localhost -Port $port -WarningAction SilentlyContinue
            if ($connection.TcpTestSucceeded) {
                $listeningPorts += $port
            }
        } catch {
            # 忽略错误
        }
    }
    
    if ($listeningPorts.Count -gt 0) {
        Write-CheckResult -Name "MCP服务器连接" -Status "PASS" -Message "检测到MCP服务器运行在端口: $($listeningPorts -join ', ')"
    } else {
        Write-CheckResult -Name "MCP服务器连接" -Status "WARN" -Message "未检测到运行的MCP服务器" -Suggestion "启动MCP服务器或检查配置"
    }
}

function Test-NodePythonRuntime {
    $nodeExists = Get-Command node -ErrorAction SilentlyContinue
    $pythonExists = Get-Command python -ErrorAction SilentlyContinue
    
    if ($nodeExists) {
        $nodeVersion = & node --version
        Write-CheckResult -Name "Node.js运行时" -Status "PASS" -Message "Node.js版本: $nodeVersion"
    } else {
        Write-CheckResult -Name "Node.js运行时" -Status "WARN" -Message "未检测到Node.js" -Suggestion "安装Node.js以运行Node MCP服务器"
    }
    
    if ($pythonExists) {
        $pythonVersion = & python --version 2>&1
        Write-CheckResult -Name "Python运行时" -Status "PASS" -Message "$pythonVersion"
    } else {
        Write-CheckResult -Name "Python运行时" -Status "WARN" -Message "未检测到Python" -Suggestion "安装Python以运行Python MCP服务器"
    }
}

# 主检测流程
Write-Host "`n🔍 MCP配置检测工具 v1.0.0" -ForegroundColor $Colors.Info
Write-Host "================================" -ForegroundColor $Colors.Info
Write-Host "检测项目: $Project`n" -ForegroundColor Gray

# 执行检测
Test-MCPConfigFile
Test-EnvironmentVariables
Test-MCPServerConnection
Test-NodePythonRuntime

# 输出总结
Write-Host "`n================================" -ForegroundColor $Colors.Info
Write-Host "📊 检测结果总结" -ForegroundColor $Colors.Info
Write-Host "================================" -ForegroundColor $Colors.Info
Write-Host "✓ 通过: $($Results.Passed)" -ForegroundColor $Colors.Success
Write-Host "⚠ 警告: $($Results.Warnings)" -ForegroundColor $Colors.Warning
Write-Host "✗ 错误: $($Results.Errors)" -ForegroundColor $Colors.Error

if ($Results.Errors -gt 0) {
    Write-Host "`n❌ 检测到严重问题，建议运行 'mcp-assistant fix' 修复" -ForegroundColor $Colors.Error
    exit 1
} elseif ($Results.Warnings -gt 0) {
    Write-Host "`n⚠️  检测到潜在问题，建议查看详情" -ForegroundColor $Colors.Warning
    exit 0
} else {
    Write-Host "`n✅ 所有检查通过！" -ForegroundColor $Colors.Success
    exit 0
}
