#!/usr/bin/env pwsh
<#
.SYNOPSIS
    MCP配置修复脚本 - 自动修复常见配置问题
.DESCRIPTION
    检测并修复MCP配置中的常见问题，包括环境变量、权限、格式等
.PARAMETER Issue
    指定要修复的问题类型
.PARAMETER DryRun
    预览修复内容，不实际执行
.PARAMETER ConfigPath
    指定配置文件路径
.EXAMPLE
    ./mcp-fix.ps1
    ./mcp-fix.ps1 --Issue env-vars
    ./mcp-fix.ps1 --DryRun
#>

param(
    [string]$Issue = "",
    [switch]$DryRun,
    [string]$ConfigPath = ""
)

$Colors = @{
    Success = "Green"
    Info = "Cyan"
    Warning = "Yellow"
    Error = "Red"
}

$FixesApplied = 0
$FixesSkipped = 0

function Write-FixResult {
    param(
        [string]$Action,
        [string]$Status,
        [string]$Details
    )
    
    $icon = switch ($Status) {
        "FIXED" { "🔧"; $Colors.Success }
        "SKIPPED" { "⏭️"; $Colors.Warning }
        "FAILED" { "❌"; $Colors.Error }
        "INFO" { "ℹ️"; $Colors.Info }
        default { "•"; $Colors.Info }
    }
    
    Write-Host "$($icon[0]) $Action" -ForegroundColor $icon[1] -NoNewline
    if ($Details) {
        Write-Host " - $Details" -ForegroundColor Gray
    } else {
        Write-Host ""
    }
}

function Find-ConfigFile {
    param([string]$Path)
    
    if ($Path -and (Test-Path $Path)) {
        return $Path
    }
    
    $searchPaths = @(
        "./mcp-config.yaml",
        "./mcp-config.yml",
        "./.mcp/config.yaml",
        "$env:USERPROFILE/.mcp/config.yaml"
    )
    
    foreach ($p in $searchPaths) {
        if (Test-Path $p) {
            return $p
        }
    }
    
    return $null
}

function Fix-EnvironmentVariables {
    Write-Host "`n📝 检查环境变量..." -ForegroundColor $Colors.Info
    
    $envFile = "./.env.mcp"
    $envContent = @"
# MCP环境变量配置
# 请根据实际情况修改以下值

# MCP服务器路径
MCP_SERVER_PATH=./server

# API密钥（请替换为实际密钥）
MCP_API_KEY=your-api-key-here

# 日志级别
MCP_LOG_LEVEL=INFO

# Python路径（如使用Python服务器）
PYTHONPATH=./src

# Node环境（如使用Node服务器）
NODE_ENV=development
"@
    
    if (Test-Path $envFile) {
        Write-FixResult -Action "环境变量文件" -Status "SKIPPED" -Details "文件已存在: $envFile"
        $script:FixesSkipped++
    } else {
        if ($DryRun) {
            Write-FixResult -Action "环境变量文件" -Status "INFO" -Details "将创建: $envFile"
        } else {
            $envContent | Out-File -FilePath $envFile -Encoding UTF8
            Write-FixResult -Action "环境变量文件" -Status "FIXED" -Details "已创建: $envFile"
            $script:FixesApplied++
        }
    }
    
    # 检查.gitignore
    $gitignore = "./.gitignore"
    $mcpEntries = @(".env.mcp", "mcp-config.yaml", ".mcp/")
    
    if (Test-Path $gitignore) {
        $content = Get-Content $gitignore -Raw
        $missingEntries = @()
        
        foreach ($entry in $mcpEntries) {
            if ($content -notmatch [regex]::Escape($entry)) {
                $missingEntries += $entry
            }
        }
        
        if ($missingEntries.Count -gt 0) {
            if ($DryRun) {
                Write-FixResult -Action ".gitignore" -Status "INFO" -Details "将添加: $($missingEntries -join ', ')"
            } else {
                Add-Content $gitignore "`n# MCP配置`n$($missingEntries -join "`n")"
                Write-FixResult -Action ".gitignore" -Status "FIXED" -Details "已添加MCP配置到忽略列表"
                $script:FixesApplied++
            }
        } else {
            Write-FixResult -Action ".gitignore" -Status "SKIPPED" -Details "MCP配置已在忽略列表中"
            $script:FixesSkipped++
        }
    } else {
        if ($DryRun) {
            Write-FixResult -Action ".gitignore" -Status "INFO" -Details "将创建.gitignore文件"
        } else {
            "# MCP配置`n$($mcpEntries -join "`n")" | Out-File -FilePath $gitignore -Encoding UTF8
            Write-FixResult -Action ".gitignore" -Status "FIXED" -Details "已创建.gitignore文件"
            $script:FixesApplied++
        }
    }
}

function Fix-ConfigPermissions {
    Write-Host "`n🔒 检查文件权限..." -ForegroundColor $Colors.Info
    
    $configFile = Find-ConfigFile -Path $ConfigPath
    
    if (-not $configFile) {
        Write-FixResult -Action "配置文件" -Status "FAILED" -Details "未找到配置文件"
        return
    }
    
    try {
        $acl = Get-Acl $configFile
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        
        # 检查当前用户是否有读写权限
        $hasAccess = $false
        foreach ($access in $acl.Access) {
            if ($access.IdentityReference.Value -eq $currentUser) {
                if ($access.FileSystemRights -band [System.Security.AccessControl.FileSystemRights]::Read -and
                    $access.FileSystemRights -band [System.Security.AccessControl.FileSystemRights]::Write) {
                    $hasAccess = $true
                    break
                }
            }
        }
        
        if ($hasAccess) {
            Write-FixResult -Action "文件权限" -Status "SKIPPED" -Details "权限正常"
            $script:FixesSkipped++
        } else {
            if ($DryRun) {
                Write-FixResult -Action "文件权限" -Status "INFO" -Details "将修复文件权限"
            } else {
                # 添加当前用户读写权限
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    $currentUser,
                    "Read,Write",
                    "Allow"
                )
                $acl.SetAccessRule($rule)
                Set-Acl $configFile $acl
                Write-FixResult -Action "文件权限" -Status "FIXED" -Details "已修复文件权限"
                $script:FixesApplied++
            }
        }
    } catch {
        Write-FixResult -Action "文件权限" -Status "FAILED" -Details "无法修改权限: $_"
    }
}

function Fix-ConfigFormat {
    Write-Host "`n📄 检查配置文件格式..." -ForegroundColor $Colors.Info
    
    $configFile = Find-ConfigFile -Path $ConfigPath
    
    if (-not $configFile) {
        Write-FixResult -Action "配置文件" -Status "FAILED" -Details "未找到配置文件"
        return
    }
    
    try {
        $content = Get-Content $configFile -Raw
        $issues = @()
        
        # 检查常见格式问题
        if ($content -match "`t") {
            $issues += "包含制表符，建议使用空格"
        }
        
        if ($content -match "\r\n") {
            $issues += "使用Windows换行符，建议统一为Unix格式"
        }
        
        if (-not ($content -match "^mcpServers:")) {
            $issues += "缺少mcpServers根节点"
        }
        
        if ($issues.Count -eq 0) {
            Write-FixResult -Action "配置文件格式" -Status "SKIPPED" -Details "格式正确"
            $script:FixesSkipped++
        } else {
            if ($DryRun) {
                Write-FixResult -Action "配置文件格式" -Status "INFO" -Details "发现 $($issues.Count) 个问题"
                foreach ($issue in $issues) {
                    Write-Host "    - $issue" -ForegroundColor Gray
                }
            } else {
                # 修复格式问题
                $fixedContent = $content
                
                # 替换制表符为4个空格
                $fixedContent = $fixedContent -replace "`t", "    "
                
                # 统一换行符
                $fixedContent = $fixedContent -replace "\r\n", "`n"
                
                # 备份原文件
                $backupPath = "$configFile.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
                Copy-Item $configFile $backupPath
                
                $fixedContent | Out-File -FilePath $configFile -Encoding UTF8
                Write-FixResult -Action "配置文件格式" -Status "FIXED" -Details "已修复格式问题，备份: $backupPath"
                $script:FixesApplied++
            }
        }
    } catch {
        Write-FixResult -Action "配置文件格式" -Status "FAILED" -Details "无法读取文件: $_"
    }
}

function Fix-ServerPaths {
    Write-Host "`n🗂️  检查服务器路径..." -ForegroundColor $Colors.Info
    
    $configFile = Find-ConfigFile -Path $ConfigPath
    
    if (-not $configFile) {
        Write-FixResult -Action "配置文件" -Status "FAILED" -Details "未找到配置文件"
        return
    }
    
    # 这里可以添加更复杂的路径验证逻辑
    Write-FixResult -Action "服务器路径" -Status "INFO" -Details "请手动验证配置文件中的路径是否正确"
}

# 主流程
Write-Host "`n🔧 MCP配置修复工具 v1.0.0" -ForegroundColor $Colors.Info
Write-Host "================================" -ForegroundColor $Colors.Info

if ($DryRun) {
    Write-Host "⚠️  干运行模式 - 不会实际修改任何文件" -ForegroundColor $Colors.Warning
}

# 执行修复
$fixesToRun = @()

if ($Issue) {
    switch ($Issue) {
        "env-vars" { $fixesToRun += "Fix-EnvironmentVariables" }
        "permissions" { $fixesToRun += "Fix-ConfigPermissions" }
        "format" { $fixesToRun += "Fix-ConfigFormat" }
        "paths" { $fixesToRun += "Fix-ServerPaths" }
        default {
            Write-Host "❌ 未知的修复类型: $Issue" -ForegroundColor $Colors.Error
            Write-Host "可用类型: env-vars, permissions, format, paths" -ForegroundColor Gray
            exit 1
        }
    }
} else {
    $fixesToRun = @("Fix-EnvironmentVariables", "Fix-ConfigPermissions", "Fix-ConfigFormat", "Fix-ServerPaths")
}

foreach ($fix in $fixesToRun) {
    & $fix
}

# 输出总结
Write-Host "`n================================" -ForegroundColor $Colors.Info
Write-Host "📊 修复总结" -ForegroundColor $Colors.Info
Write-Host "================================" -ForegroundColor $Colors.Info

if ($DryRun) {
    Write-Host "🔍 干运行模式 - 未应用任何更改" -ForegroundColor $Colors.Warning
} else {
    Write-Host "✅ 已修复: $FixesApplied" -ForegroundColor $Colors.Success
    Write-Host "⏭️  已跳过: $FixesSkipped" -ForegroundColor $Colors.Warning
}

if ($FixesApplied -gt 0) {
    Write-Host "`n💡 建议运行 'mcp-assistant check' 验证修复结果" -ForegroundColor $Colors.Info
}

Write-Host ""
